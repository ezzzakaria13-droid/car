export function normalizePhone(phone: string): string {
  // Remove all non-digit characters
  let normalized = phone.replace(/[^0-9]/g, "")

  // Add country code if missing (assuming Saudi Arabia +966)
  if (normalized.length === 9) {
    normalized = "966" + normalized
  } else if (normalized.length === 10 && normalized.startsWith("0")) {
    normalized = "966" + normalized.substring(1)
  }

  return normalized
}

export function formatPhone(phone: string): string {
  const normalized = normalizePhone(phone)

  if (normalized.startsWith("966")) {
    const local = normalized.substring(3)
    return `+966 ${local.substring(0, 2)} ${local.substring(2, 5)} ${local.substring(5)}`
  }

  return phone
}

export function getWhatsAppLink(phone: string, message?: string): string {
  const normalized = normalizePhone(phone)
  const encodedMessage = message ? encodeURIComponent(message) : ""
  return `https://wa.me/${normalized}${message ? `?text=${encodedMessage}` : ""}`
}
