"use server"

import { cookies } from "next/headers"

export async function getUserId() {
  const cookieStore = await cookies()
  const userId = cookieStore.get("user_id")?.value
  console.log("[v0] getUserId called, found:", userId)
  return userId || null
}
