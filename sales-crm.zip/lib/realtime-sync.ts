import { createClient } from "@/lib/supabase/client"
import type { RealtimeChannel } from "@supabase/supabase-js"

export class RealtimeSync {
  private channels: Map<string, RealtimeChannel> = new Map()
  private supabase = createClient()

  // Subscribe to table changes
  subscribeToTable(
    tableName: string,
    callback: (payload: any) => void,
    filter?: { column: string; value: string },
  ): () => void {
    const channelName = filter ? `${tableName}_${filter.column}_${filter.value}` : tableName

    // Remove existing channel if it exists
    if (this.channels.has(channelName)) {
      this.unsubscribe(channelName)
    }

    const channel = this.supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: tableName,
          ...(filter && { filter: `${filter.column}=eq.${filter.value}` }),
        },
        (payload) => {
          callback(payload)
        },
      )
      .subscribe()

    this.channels.set(channelName, channel)

    // Return unsubscribe function
    return () => this.unsubscribe(channelName)
  }

  // Subscribe to presence (online users)
  subscribeToPresence(roomName: string, onJoin: (user: any) => void, onLeave: (user: any) => void): () => void {
    const channelName = `presence_${roomName}`

    if (this.channels.has(channelName)) {
      this.unsubscribe(channelName)
    }

    const channel = this.supabase.channel(channelName, {
      config: {
        presence: {
          key: "user",
        },
      },
    })

    channel
      .on("presence", { event: "join" }, ({ newPresences }) => {
        newPresences.forEach((presence) => onJoin(presence))
      })
      .on("presence", { event: "leave" }, ({ leftPresences }) => {
        leftPresences.forEach((presence) => onLeave(presence))
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          const {
            data: { user },
          } = await this.supabase.auth.getUser()
          if (user) {
            const { data: employee } = await this.supabase
              .from("employees")
              .select("name, role")
              .eq("id", user.id)
              .single()

            await channel.track({
              user_id: user.id,
              name: employee?.name || "Unknown",
              role: employee?.role || "employee",
              online_at: new Date().toISOString(),
            })
          }
        }
      })

    this.channels.set(channelName, channel)

    return () => this.unsubscribe(channelName)
  }

  // Broadcast message to all connected clients
  async broadcast(channelName: string, event: string, payload: any): Promise<void> {
    let channel = this.channels.get(channelName)

    if (!channel) {
      channel = this.supabase.channel(channelName)
      await channel.subscribe()
      this.channels.set(channelName, channel)
    }

    await channel.send({
      type: "broadcast",
      event,
      payload,
    })
  }

  // Subscribe to broadcast messages
  subscribeToBroadcast(channelName: string, event: string, callback: (payload: any) => void): () => void {
    if (this.channels.has(channelName)) {
      this.unsubscribe(channelName)
    }

    const channel = this.supabase.channel(channelName).on("broadcast", { event }, ({ payload }) => {
      callback(payload)
    })

    channel.subscribe()
    this.channels.set(channelName, channel)

    return () => this.unsubscribe(channelName)
  }

  // Unsubscribe from a channel
  private unsubscribe(channelName: string): void {
    const channel = this.channels.get(channelName)
    if (channel) {
      this.supabase.removeChannel(channel)
      this.channels.delete(channelName)
    }
  }

  // Unsubscribe from all channels
  unsubscribeAll(): void {
    this.channels.forEach((_, channelName) => {
      this.unsubscribe(channelName)
    })
  }
}

// Singleton instance
let realtimeSyncInstance: RealtimeSync | null = null

export function getRealtimeSync(): RealtimeSync {
  if (!realtimeSyncInstance) {
    realtimeSyncInstance = new RealtimeSync()
  }
  return realtimeSyncInstance
}
