import { createClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"

export async function getCurrentUser() {
  console.log("[v0] Getting current user...")

  const cookieStore = await cookies()
  const userId = cookieStore.get("user_id")?.value

  if (!userId) {
    console.log("[v0] No user_id cookie found")
    return null
  }

  const supabase = await createClient()

  const { data: employee, error } = await supabase
    .from("employees")
    .select("*")
    .eq("id", userId)
    .eq("status", "active")
    .single()

  if (error || !employee) {
    console.log("[v0] Employee not found or error:", error)
    return null
  }

  console.log("[v0] Current user:", employee.name, "Role:", employee.role)
  return employee
}

export async function isAdmin() {
  const user = await getCurrentUser()
  const result = user?.role === "admin"
  console.log("[v0] Is admin check:", result)
  return result
}
