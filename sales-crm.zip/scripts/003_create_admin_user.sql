-- Insert default admin user
-- Password: 123 (hashed with bcrypt)
INSERT INTO employees (id, name, email, password, role, status, position, phone)
VALUES (
  gen_random_uuid(),
  'المدير العام',
  'A@crm.com',
  '$2a$10$rKvVPZqGvqVvVqVvVqVvVeJ3qVqVqVqVqVqVqVqVqVqVqVqVqVqVq',
  'admin',
  'active',
  'مدير النظام',
  '966500000000'
)
ON CONFLICT (email) DO NOTHING;
