-- Enable Row Level Security on all tables
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE phone_numbers ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Employees policies
CREATE POLICY "Employees can view all employees"
  ON employees FOR SELECT
  USING (true);

CREATE POLICY "Only admins can insert employees"
  ON employees FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can update employees"
  ON employees FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete employees"
  ON employees FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Customers policies
CREATE POLICY "Employees can view their assigned customers"
  ON customers FOR SELECT
  USING (
    assigned_to = auth.uid() OR
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Employees can insert customers"
  ON customers FOR INSERT
  WITH CHECK (
    assigned_to = auth.uid() OR
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Employees can update their customers"
  ON customers FOR UPDATE
  USING (
    assigned_to = auth.uid() OR
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete customers"
  ON customers FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Notes policies
CREATE POLICY "Employees can view notes for their customers"
  ON notes FOR SELECT
  USING (
    employee_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Employees can insert their own notes"
  ON notes FOR INSERT
  WITH CHECK (employee_id = auth.uid());

CREATE POLICY "Employees can update their own notes"
  ON notes FOR UPDATE
  USING (employee_id = auth.uid());

CREATE POLICY "Employees can delete their own notes"
  ON notes FOR DELETE
  USING (employee_id = auth.uid());

-- Notifications policies
CREATE POLICY "Users can view their notifications"
  ON notifications FOR SELECT
  USING (recipient_id = auth.uid());

CREATE POLICY "Users can insert notifications"
  ON notifications FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their notifications"
  ON notifications FOR UPDATE
  USING (recipient_id = auth.uid());

CREATE POLICY "Users can delete their notifications"
  ON notifications FOR DELETE
  USING (recipient_id = auth.uid());

-- Phone numbers policies
CREATE POLICY "Employees can view all phone numbers"
  ON phone_numbers FOR SELECT
  USING (true);

CREATE POLICY "Employees can insert phone numbers"
  ON phone_numbers FOR INSERT
  WITH CHECK (added_by = auth.uid());

CREATE POLICY "Only admins can update phone numbers"
  ON phone_numbers FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete phone numbers"
  ON phone_numbers FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Quotations policies
CREATE POLICY "Employees can view their quotations"
  ON quotations FOR SELECT
  USING (
    employee_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Employees can insert their quotations"
  ON quotations FOR INSERT
  WITH CHECK (employee_id = auth.uid());

CREATE POLICY "Employees can update their quotations"
  ON quotations FOR UPDATE
  USING (employee_id = auth.uid());

CREATE POLICY "Employees can delete their quotations"
  ON quotations FOR DELETE
  USING (employee_id = auth.uid());

-- Settings policies
CREATE POLICY "Everyone can view settings"
  ON settings FOR SELECT
  USING (true);

CREATE POLICY "Only admins can modify settings"
  ON settings FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Only admins can update settings"
  ON settings FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM employees 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
