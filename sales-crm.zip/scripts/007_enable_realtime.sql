-- تفعيل Realtime على جميع الجداول
-- ملاحظة: هذا السكريبت يجب تشغيله من Supabase Dashboard
-- لأن تفعيل Realtime يتطلب صلاحيات خاصة

-- تفعيل Realtime للجداول
ALTER PUBLICATION supabase_realtime ADD TABLE employees;
ALTER PUBLICATION supabase_realtime ADD TABLE customers;
ALTER PUBLICATION supabase_realtime ADD TABLE notes;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE phone_numbers;
ALTER PUBLICATION supabase_realtime ADD TABLE quotations;
ALTER PUBLICATION supabase_realtime ADD TABLE settings;
ALTER PUBLICATION supabase_realtime ADD TABLE files;

-- رسالة تأكيد
DO $$
BEGIN
  RAISE NOTICE '✅ تم تفعيل Realtime على جميع الجداول';
  RAISE NOTICE 'ℹ️ إذا واجهت خطأ، قم بتفعيل Realtime يدوياً من:';
  RAISE NOTICE '   Supabase Dashboard → Database → Replication';
END $$;
