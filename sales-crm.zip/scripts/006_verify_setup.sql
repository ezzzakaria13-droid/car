-- سكريبت التحقق من إعداد النظام بشكل صحيح
-- قم بتشغيل هذا السكريبت للتأكد من أن كل شيء يعمل بشكل صحيح

-- ==========================================
-- 1. التحقق من الجداول
-- ==========================================
DO $$
DECLARE
  table_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO table_count
  FROM information_schema.tables 
  WHERE table_schema = 'public' 
  AND table_name IN ('employees', 'customers', 'notes', 'notifications', 'phone_numbers', 'quotations', 'settings', 'files');
  
  IF table_count = 8 THEN
    RAISE NOTICE '✅ جميع الجداول موجودة (8/8)';
  ELSE
    RAISE WARNING '⚠️ بعض الجداول مفقودة! موجود: % من 8', table_count;
  END IF;
END $$;

-- ==========================================
-- 2. التحقق من تفعيل RLS
-- ==========================================
DO $$
DECLARE
  rls_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO rls_count
  FROM pg_tables 
  WHERE schemaname = 'public' 
  AND rowsecurity = true
  AND tablename IN ('employees', 'customers', 'notes', 'notifications', 'phone_numbers', 'quotations', 'settings', 'files');
  
  IF rls_count = 8 THEN
    RAISE NOTICE '✅ RLS مفعل على جميع الجداول (8/8)';
  ELSE
    RAISE WARNING '⚠️ RLS غير مفعل على بعض الجداول! مفعل على: % من 8', rls_count;
  END IF;
END $$;

-- ==========================================
-- 3. التحقق من السياسات (Policies)
-- ==========================================
DO $$
DECLARE
  policy_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO policy_count
  FROM pg_policies 
  WHERE schemaname = 'public';
  
  IF policy_count >= 30 THEN
    RAISE NOTICE '✅ السياسات موجودة (%)', policy_count;
  ELSE
    RAISE WARNING '⚠️ عدد السياسات قليل! موجود: %', policy_count;
  END IF;
END $$;

-- ==========================================
-- 4. التحقق من الدوال (Functions)
-- ==========================================
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'normalize_phone') THEN
    RAISE NOTICE '✅ دالة normalize_phone موجودة';
  ELSE
    RAISE WARNING '⚠️ دالة normalize_phone مفقودة!';
  END IF;
  
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'check_duplicate_phone') THEN
    RAISE NOTICE '✅ دالة check_duplicate_phone موجودة';
  ELSE
    RAISE WARNING '⚠️ دالة check_duplicate_phone مفقودة!';
  END IF;
  
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column') THEN
    RAISE NOTICE '✅ دالة update_updated_at_column موجودة';
  ELSE
    RAISE WARNING '⚠️ دالة update_updated_at_column مفقودة!';
  END IF;
END $$;

-- ==========================================
-- 5. التحقق من المحفزات (Triggers)
-- ==========================================
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'normalize_customer_phone') THEN
    RAISE NOTICE '✅ محفز normalize_customer_phone موجود';
  ELSE
    RAISE WARNING '⚠️ محفز normalize_customer_phone مفقود!';
  END IF;
  
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_customers_updated_at') THEN
    RAISE NOTICE '✅ محفز update_customers_updated_at موجود';
  ELSE
    RAISE WARNING '⚠️ محفز update_customers_updated_at مفقود!';
  END IF;
END $$;

-- ==========================================
-- 6. التحقق من الفهارس (Indexes)
-- ==========================================
DO $$
DECLARE
  index_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO index_count
  FROM pg_indexes 
  WHERE schemaname = 'public'
  AND indexname LIKE 'idx_%';
  
  IF index_count >= 8 THEN
    RAISE NOTICE '✅ الفهارس موجودة (%)', index_count;
  ELSE
    RAISE WARNING '⚠️ بعض الفهارس مفقودة! موجود: %', index_count;
  END IF;
END $$;

-- ==========================================
-- 7. التحقق من المستخدمين
-- ==========================================
DO $$
DECLARE
  admin_count INTEGER;
  employee_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO admin_count FROM employees WHERE role = 'admin';
  SELECT COUNT(*) INTO employee_count FROM employees WHERE role = 'employee';
  
  IF admin_count > 0 THEN
    RAISE NOTICE '✅ يوجد % مدير', admin_count;
  ELSE
    RAISE WARNING '⚠️ لا يوجد مدراء! قم بتشغيل 003_create_admin_user.sql';
  END IF;
  
  IF employee_count > 0 THEN
    RAISE NOTICE '✅ يوجد % موظف', employee_count;
  ELSE
    RAISE NOTICE 'ℹ️ لا يوجد موظفين (اختياري)';
  END IF;
END $$;

-- ==========================================
-- 8. التحقق من البيانات التجريبية
-- ==========================================
DO $$
DECLARE
  customer_count INTEGER;
  note_count INTEGER;
  quote_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO customer_count FROM customers;
  SELECT COUNT(*) INTO note_count FROM notes;
  SELECT COUNT(*) INTO quote_count FROM quotations;
  
  RAISE NOTICE 'ℹ️ عدد العملاء: %', customer_count;
  RAISE NOTICE 'ℹ️ عدد الملاحظات: %', note_count;
  RAISE NOTICE 'ℹ️ عدد عروض الأسعار: %', quote_count;
END $$;

-- ==========================================
-- 9. اختبار دالة تطبيع الأرقام
-- ==========================================
DO $$
DECLARE
  test_result TEXT;
BEGIN
  SELECT normalize_phone('0501234567') INTO test_result;
  IF test_result = '966501234567' THEN
    RAISE NOTICE '✅ دالة تطبيع الأرقام تعمل بشكل صحيح';
  ELSE
    RAISE WARNING '⚠️ دالة تطبيع الأرقام لا تعمل! النتيجة: %', test_result;
  END IF;
END $$;

-- ==========================================
-- 10. ملخص النتائج
-- ==========================================
SELECT 
  '========================================' as "ملخص التحقق",
  '' as " "
UNION ALL
SELECT 
  'الجداول',
  CAST(COUNT(*) as TEXT) || '/8'
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('employees', 'customers', 'notes', 'notifications', 'phone_numbers', 'quotations', 'settings', 'files')

UNION ALL
SELECT 
  'RLS مفعل',
  CAST(COUNT(*) as TEXT) || '/8'
FROM pg_tables 
WHERE schemaname = 'public' 
AND rowsecurity = true

UNION ALL
SELECT 
  'السياسات',
  CAST(COUNT(*) as TEXT)
FROM pg_policies 
WHERE schemaname = 'public'

UNION ALL
SELECT 
  'الدوال',
  CAST(COUNT(*) as TEXT) || '/3'
FROM pg_proc 
WHERE proname IN ('normalize_phone', 'check_duplicate_phone', 'update_updated_at_column')

UNION ALL
SELECT 
  'المحفزات',
  CAST(COUNT(*) as TEXT) || '/2'
FROM pg_trigger 
WHERE tgname IN ('normalize_customer_phone', 'update_customers_updated_at')

UNION ALL
SELECT 
  'المدراء',
  CAST(COUNT(*) as TEXT)
FROM employees 
WHERE role = 'admin'

UNION ALL
SELECT 
  'الموظفون',
  CAST(COUNT(*) as TEXT)
FROM employees 
WHERE role = 'employee'

UNION ALL
SELECT 
  'العملاء',
  CAST(COUNT(*) as TEXT)
FROM customers

UNION ALL
SELECT 
  '========================================',
  '';
