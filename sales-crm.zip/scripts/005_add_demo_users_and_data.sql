-- إضافة مستخدمين تجريبيين وبيانات تجريبية
-- Demo Users and Sample Data

-- حذف البيانات التجريبية القديمة إن وجدت
DELETE FROM notes WHERE employee_id IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com');
DELETE FROM customers WHERE assigned_to IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com');
DELETE FROM employees WHERE email LIKE '%@demo.crm.com';

-- إضافة موظفين تجريبيين
-- Adding demo employees
INSERT INTO employees (name, email, password, role, status, position, phone, hire_date) VALUES
  ('أحمد محمد', 'ahmed@demo.crm.com', crypt('ahmed2024', gen_salt('bf')), 'employee', 'active', 'مندوب مبيعات', '+966501234567', CURRENT_DATE - INTERVAL '6 months'),
  ('فاطمة علي', 'fatima@demo.crm.com', crypt('fatima2024', gen_salt('bf')), 'employee', 'active', 'مندوبة مبيعات', '+966502345678', CURRENT_DATE - INTERVAL '4 months'),
  ('محمد حسن', 'mohammed@demo.crm.com', crypt('mohammed2024', gen_salt('bf')), 'employee', 'active', 'مندوب مبيعات', '+966503456789', CURRENT_DATE - INTERVAL '3 months'),
  ('سارة خالد', 'sara@demo.crm.com', crypt('sara2024', gen_salt('bf')), 'employee', 'active', 'مندوبة مبيعات', '+966504567890', CURRENT_DATE - INTERVAL '2 months');

-- إضافة عملاء تجريبيين
-- Adding demo customers
INSERT INTO customers (name, phone, email, status, source, assigned_to, notes, created_at) 
SELECT 
  'عميل تجريبي ' || generate_series,
  '+9665' || LPAD((500000000 + generate_series)::text, 9, '0'),
  'customer' || generate_series || '@example.com',
  CASE (random() * 4)::int
    WHEN 0 THEN 'new'
    WHEN 1 THEN 'contacted'
    WHEN 2 THEN 'interested'
    WHEN 3 THEN 'negotiating'
    ELSE 'closed'
  END,
  CASE (random() * 3)::int
    WHEN 0 THEN 'whatsapp'
    WHEN 1 THEN 'phone'
    WHEN 2 THEN 'website'
    ELSE 'referral'
  END,
  (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com' ORDER BY random() LIMIT 1),
  'عميل تجريبي للاختبار',
  CURRENT_TIMESTAMP - (random() * INTERVAL '30 days')
FROM generate_series(1, 20);

-- إضافة ملاحظات تجريبية
-- Adding demo notes
INSERT INTO notes (customer_id, employee_id, content, note_type, reminder_date, is_reminder, created_at)
SELECT 
  c.id,
  c.assigned_to,
  CASE (random() * 3)::int
    WHEN 0 THEN 'تم التواصل مع العميل وأبدى اهتماماً بسيارة كامري 2024'
    WHEN 1 THEN 'العميل يطلب عرض سعر للتمويل'
    WHEN 2 THEN 'موعد زيارة المعرض يوم الأحد القادم'
    ELSE 'العميل يفضل التواصل عبر الواتساب'
  END,
  CASE (random() * 2)::int
    WHEN 0 THEN 'note'
    ELSE 'reminder'
  END,
  CASE 
    WHEN (random() * 2)::int = 1 THEN CURRENT_DATE + (random() * 7)::int
    ELSE NULL
  END,
  (random() * 2)::int = 1,
  CURRENT_TIMESTAMP - (random() * INTERVAL '10 days')
FROM customers c
WHERE c.assigned_to IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com')
LIMIT 30;

-- إضافة عروض أسعار تجريبية
-- Adding demo quotations
INSERT INTO quotations (customer_id, employee_id, items, total_amount, status, valid_until, notes, created_at)
SELECT 
  c.id,
  c.assigned_to,
  jsonb_build_array(
    jsonb_build_object(
      'description', 'تويوتا كامري 2024 - فل كامل',
      'quantity', 1,
      'price', 125000,
      'total', 125000
    ),
    jsonb_build_object(
      'description', 'تأمين شامل - سنة واحدة',
      'quantity', 1,
      'price', 3500,
      'total', 3500
    ),
    jsonb_build_object(
      'description', 'صيانة مجانية - سنتين',
      'quantity', 1,
      'price', 0,
      'total', 0
    )
  ),
  128500,
  CASE (random() * 2)::int
    WHEN 0 THEN 'pending'
    WHEN 1 THEN 'accepted'
    ELSE 'rejected'
  END,
  CURRENT_DATE + INTERVAL '30 days',
  'عرض خاص للعميل',
  CURRENT_TIMESTAMP - (random() * INTERVAL '15 days')
FROM customers c
WHERE c.assigned_to IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com')
LIMIT 10;

-- إضافة إشعارات تجريبية
-- Adding demo notifications
INSERT INTO notifications (user_id, title, message, type, is_read, created_at)
SELECT 
  e.id,
  'تذكير: متابعة عميل',
  'لديك موعد مع عميل اليوم الساعة 3 مساءً',
  'reminder',
  false,
  CURRENT_TIMESTAMP - INTERVAL '2 hours'
FROM employees e
WHERE e.email LIKE '%@demo.crm.com'
LIMIT 5;

-- عرض ملخص البيانات المضافة
SELECT 
  'تم إضافة البيانات التجريبية بنجاح' as status,
  (SELECT COUNT(*) FROM employees WHERE email LIKE '%@demo.crm.com') as demo_employees,
  (SELECT COUNT(*) FROM customers WHERE assigned_to IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com')) as demo_customers,
  (SELECT COUNT(*) FROM notes WHERE employee_id IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com')) as demo_notes,
  (SELECT COUNT(*) FROM quotations WHERE employee_id IN (SELECT id FROM employees WHERE email LIKE '%@demo.crm.com')) as demo_quotations;
