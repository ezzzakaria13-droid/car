"use client"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Upload, FileText, ImageIcon, File, Download, Trash2, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { formatDistanceToNow } from "date-fns"
import { ar } from "date-fns/locale"

interface FileRecord {
  id: string
  name: string
  description: string
  file_type: string
  file_size: number
  file_url: string
  uploaded_by: string
  created_at: string
  employee?: {
    name: string
  }
}

export default function FilesPage() {
  const [files, setFiles] = useState<FileRecord[]>([])
  const [filteredFiles, setFilteredFiles] = useState<FileRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    file: null as File | null,
  })
  const { toast } = useToast()
  const supabase = createBrowserClient()

  useEffect(() => {
    loadFiles()
  }, [])

  useEffect(() => {
    filterFiles()
  }, [files, searchQuery, filterType])

  const loadFiles = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from("files")
        .select(`
          *,
          employee:employees(name)
        `)
        .order("created_at", { ascending: false })

      if (error) throw error
      setFiles(data || [])
    } catch (error) {
      console.error("Error loading files:", error)
      toast({
        title: "خطأ",
        description: "فشل تحميل الملفات",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterFiles = () => {
    let filtered = files

    if (searchQuery) {
      filtered = filtered.filter(
        (file) =>
          file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          file.description?.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    if (filterType !== "all") {
      filtered = filtered.filter((file) => file.file_type.startsWith(filterType))
    }

    setFilteredFiles(filtered)
  }

  const handleUpload = async () => {
    if (!formData.file || !formData.name) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive",
      })
      return
    }

    try {
      setUploading(true)

      // Get current user
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("User not authenticated")

      // Upload file to Supabase Storage
      const fileExt = formData.file.name.split(".").pop()
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`
      const filePath = `uploads/${fileName}`

      const { error: uploadError } = await supabase.storage.from("files").upload(filePath, formData.file)

      if (uploadError) throw uploadError

      // Get public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from("files").getPublicUrl(filePath)

      // Save file record to database
      const { error: dbError } = await supabase.from("files").insert({
        name: formData.name,
        description: formData.description,
        file_type: formData.file.type,
        file_size: formData.file.size,
        file_url: publicUrl,
        uploaded_by: user.id,
      })

      if (dbError) throw dbError

      toast({
        title: "تم الرفع",
        description: "تم رفع الملف بنجاح",
      })

      setIsDialogOpen(false)
      setFormData({ name: "", description: "", file: null })
      loadFiles()
    } catch (error) {
      console.error("Error uploading file:", error)
      toast({
        title: "خطأ",
        description: "فشل رفع الملف",
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  const handleDelete = async (id: string, fileUrl: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا الملف؟")) return

    try {
      // Extract file path from URL
      const filePath = fileUrl.split("/").slice(-2).join("/")

      // Delete from storage
      await supabase.storage.from("files").remove([filePath])

      // Delete from database
      const { error } = await supabase.from("files").delete().eq("id", id)

      if (error) throw error

      toast({
        title: "تم الحذف",
        description: "تم حذف الملف بنجاح",
      })

      loadFiles()
    } catch (error) {
      console.error("Error deleting file:", error)
      toast({
        title: "خطأ",
        description: "فشل حذف الملف",
        variant: "destructive",
      })
    }
  }

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith("image/")) return <ImageIcon className="h-5 w-5" />
    if (fileType.startsWith("application/pdf")) return <FileText className="h-5 w-5" />
    return <File className="h-5 w-5" />
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل الملفات...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">إدارة الملفات</h1>
          <p className="text-muted-foreground mt-1">رفع ومشاركة الملفات والمستندات</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Upload className="ml-2 h-4 w-4" />
              رفع ملف جديد
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>رفع ملف جديد</DialogTitle>
              <DialogDescription>قم برفع ملف أو مستند لمشاركته مع الفريق</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">اسم الملف *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="أدخل اسم الملف"
                />
              </div>
              <div>
                <Label htmlFor="description">الوصف</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="أدخل وصف الملف (اختياري)"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="file">الملف *</Label>
                <Input
                  id="file"
                  type="file"
                  onChange={(e) => setFormData({ ...formData, file: e.target.files?.[0] || null })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                إلغاء
              </Button>
              <Button onClick={handleUpload} disabled={uploading}>
                {uploading ? "جاري الرفع..." : "رفع الملف"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="البحث في الملفات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant={filterType === "all" ? "default" : "outline"} onClick={() => setFilterType("all")}>
                الكل
              </Button>
              <Button variant={filterType === "image" ? "default" : "outline"} onClick={() => setFilterType("image")}>
                صور
              </Button>
              <Button
                variant={filterType === "application" ? "default" : "outline"}
                onClick={() => setFilterType("application")}
              >
                مستندات
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Files Table */}
      <Card>
        <CardHeader>
          <CardTitle>الملفات ({filteredFiles.length})</CardTitle>
          <CardDescription>جميع الملفات المرفوعة في النظام</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>النوع</TableHead>
                <TableHead>الاسم</TableHead>
                <TableHead>الوصف</TableHead>
                <TableHead>الحجم</TableHead>
                <TableHead>رفع بواسطة</TableHead>
                <TableHead>التاريخ</TableHead>
                <TableHead className="text-left">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFiles.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    لا توجد ملفات
                  </TableCell>
                </TableRow>
              ) : (
                filteredFiles.map((file) => (
                  <TableRow key={file.id}>
                    <TableCell>{getFileIcon(file.file_type)}</TableCell>
                    <TableCell className="font-medium">{file.name}</TableCell>
                    <TableCell className="text-muted-foreground">{file.description || "-"}</TableCell>
                    <TableCell>{formatFileSize(file.file_size)}</TableCell>
                    <TableCell>{file.employee?.name || "غير معروف"}</TableCell>
                    <TableCell>
                      {formatDistanceToNow(new Date(file.created_at), { addSuffix: true, locale: ar })}
                    </TableCell>
                    <TableCell className="text-left">
                      <div className="flex gap-2 justify-end">
                        <Button variant="outline" size="sm" onClick={() => window.open(file.file_url, "_blank")}>
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDelete(file.id, file.file_url)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
