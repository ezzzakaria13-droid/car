"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, User, Clock, CheckCircle, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { formatPhone, getWhatsAppLink } from "@/lib/phone-utils"

interface QueueItem {
  id: string
  phone: string
  source: string
  status: string
  assigned_to: string | null
  created_at: string
  employees?: {
    name: string
  }
}

interface Employee {
  id: string
  name: string
}

export default function WhatsAppQueuePage() {
  const [queueItems, setQueueItems] = useState<QueueItem[]>([])
  const [filteredItems, setFilteredItems] = useState<QueueItem[]>([])
  const [employees, setEmployees] = useState<Employee[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    loadQueue()
    loadEmployees()

    // Subscribe to real-time updates
    const channel = supabase
      .channel("phone_numbers")
      .on("postgres_changes", { event: "*", schema: "public", table: "phone_numbers" }, () => {
        loadQueue()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    let filtered = queueItems

    if (searchTerm) {
      filtered = filtered.filter((item) => item.phone.includes(searchTerm))
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter((item) => item.status === statusFilter)
    }

    setFilteredItems(filtered)
  }, [searchTerm, statusFilter, queueItems])

  const loadQueue = async () => {
    const { data } = await supabase
      .from("phone_numbers")
      .select("*, employees(name)")
      .order("created_at", { ascending: false })

    if (data) {
      setQueueItems(data)
      setFilteredItems(data)
    }
  }

  const loadEmployees = async () => {
    const { data } = await supabase.from("employees").select("id, name").eq("status", "active").eq("role", "employee")

    if (data) {
      setEmployees(data)
    }
  }

  const handleAssign = async (phoneId: string, employeeId: string) => {
    try {
      const { error } = await supabase
        .from("phone_numbers")
        .update({ assigned_to: employeeId, status: "assigned" })
        .eq("id", phoneId)

      if (error) throw error

      // Send notification
      const {
        data: { user },
      } = await supabase.auth.getUser()

      await supabase.from("notifications").insert({
        recipient_id: employeeId,
        sender_id: user?.id,
        title: "رقم جديد من طابور الواتساب",
        message: "تم تعيين رقم جديد لك من طابور الواتساب",
      })

      toast({
        title: "تم التعيين",
        description: "تم تعيين الرقم للموظف بنجاح",
      })

      loadQueue()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleStatusChange = async (phoneId: string, newStatus: string) => {
    try {
      const { error } = await supabase.from("phone_numbers").update({ status: newStatus }).eq("id", phoneId)

      if (error) throw error

      toast({
        title: "تم التحديث",
        description: "تم تحديث حالة الرقم",
      })

      loadQueue()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      pending: { label: "قيد الانتظار", variant: "secondary" },
      assigned: { label: "تم التعيين", variant: "default" },
      contacted: { label: "تم التواصل", variant: "outline" },
      completed: { label: "مكتمل", variant: "default" },
    }

    const config = statusMap[status] || { label: status, variant: "outline" }
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  const stats = {
    total: queueItems.length,
    pending: queueItems.filter((i) => i.status === "pending").length,
    assigned: queueItems.filter((i) => i.status === "assigned").length,
    completed: queueItems.filter((i) => i.status === "completed").length,
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">طابور الواتساب</h1>
        <p className="text-muted-foreground">إدارة الأرقام الواردة من الواتساب</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الأرقام</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">قيد الانتظار</CardTitle>
            <Clock className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">تم التعيين</CardTitle>
            <User className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.assigned}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">مكتمل</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completed}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>قائمة الأرقام</CardTitle>
            <div className="flex gap-2">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="البحث برقم الهاتف..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="assigned">تم التعيين</SelectItem>
                  <SelectItem value="contacted">تم التواصل</SelectItem>
                  <SelectItem value="completed">مكتمل</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="p-3 text-right font-semibold">رقم الهاتف</th>
                  <th className="p-3 text-right font-semibold">المصدر</th>
                  <th className="p-3 text-right font-semibold">الحالة</th>
                  <th className="p-3 text-right font-semibold">المعين له</th>
                  <th className="p-3 text-right font-semibold">التاريخ</th>
                  <th className="p-3 text-right font-semibold">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredItems.map((item) => (
                  <tr key={item.id} className="border-b hover:bg-accent/50">
                    <td className="p-3">
                      <a
                        href={getWhatsAppLink(item.phone)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-blue-600 hover:underline"
                      >
                        <MessageSquare className="h-4 w-4" />
                        {formatPhone(item.phone)}
                      </a>
                    </td>
                    <td className="p-3">{item.source}</td>
                    <td className="p-3">{getStatusBadge(item.status)}</td>
                    <td className="p-3">{item.employees?.name || "غير محدد"}</td>
                    <td className="p-3 text-sm text-muted-foreground">
                      {new Date(item.created_at).toLocaleDateString("ar-SA")}
                    </td>
                    <td className="p-3">
                      <div className="flex gap-2">
                        {!item.assigned_to && (
                          <Select onValueChange={(value) => handleAssign(item.id, value)}>
                            <SelectTrigger className="w-32">
                              <SelectValue placeholder="تعيين" />
                            </SelectTrigger>
                            <SelectContent>
                              {employees.map((emp) => (
                                <SelectItem key={emp.id} value={emp.id}>
                                  {emp.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                        <Select value={item.status} onValueChange={(value) => handleStatusChange(item.id, value)}>
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">قيد الانتظار</SelectItem>
                            <SelectItem value="assigned">تم التعيين</SelectItem>
                            <SelectItem value="contacted">تم التواصل</SelectItem>
                            <SelectItem value="completed">مكتمل</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
