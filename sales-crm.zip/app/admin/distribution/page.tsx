"use client"

import React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, Users, FileSpreadsheet } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { normalizePhone } from "@/lib/phone-utils"
import * as XLSX from "xlsx"

interface Employee {
  id: string
  name: string
}

export default function DistributionPage() {
  const [file, setFile] = useState<File | null>(null)
  const [employees, setEmployees] = useState<Employee[]>([])
  const [selectedEmployee, setSelectedEmployee] = useState<string>("")
  const [distributionMethod, setDistributionMethod] = useState<"manual" | "auto">("manual")
  const [isProcessing, setIsProcessing] = useState(false)
  const [phoneNumbers, setPhoneNumbers] = useState<string[]>([])
  const [manualInput, setManualInput] = useState("")
  const supabase = createClient()
  const { toast } = useToast()

  React.useEffect(() => {
    loadEmployees()
  }, [])

  const loadEmployees = async () => {
    const { data } = await supabase.from("employees").select("id, name").eq("status", "active").eq("role", "employee")

    if (data) {
      setEmployees(data)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0]
    if (!uploadedFile) return

    setFile(uploadedFile)

    try {
      const data = await uploadedFile.arrayBuffer()
      const workbook = XLSX.read(data)
      const worksheet = workbook.Sheets[workbook.SheetNames[0]]
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as string[][]

      // Extract phone numbers from all columns
      const phones: string[] = []
      jsonData.forEach((row) => {
        row.forEach((cell) => {
          if (cell && typeof cell === "string") {
            const normalized = normalizePhone(cell)
            if (normalized.length >= 9) {
              phones.push(normalized)
            }
          }
        })
      })

      // Remove duplicates
      const uniquePhones = [...new Set(phones)]
      setPhoneNumbers(uniquePhones)

      toast({
        title: "تم تحميل الملف",
        description: `تم العثور على ${uniquePhones.length} رقم هاتف`,
      })
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في قراءة الملف",
        variant: "destructive",
      })
    }
  }

  const handleManualInput = () => {
    const lines = manualInput.split("\n").filter((line) => line.trim())
    const phones = lines.map((line) => normalizePhone(line.trim())).filter((phone) => phone.length >= 9)

    // Remove duplicates
    const uniquePhones = [...new Set(phones)]
    setPhoneNumbers(uniquePhones)

    toast({
      title: "تم إضافة الأرقام",
      description: `تم إضافة ${uniquePhones.length} رقم هاتف`,
    })
  }

  const handleDistribute = async () => {
    if (phoneNumbers.length === 0) {
      toast({
        title: "خطأ",
        description: "لا توجد أرقام للتوزيع",
        variant: "destructive",
      })
      return
    }

    if (distributionMethod === "manual" && !selectedEmployee) {
      toast({
        title: "خطأ",
        description: "يرجى اختيار موظف",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (distributionMethod === "manual") {
        // Check for duplicates in database
        const { data: existingPhones } = await supabase.from("customers").select("phone").in("phone", phoneNumbers)

        const existingSet = new Set(existingPhones?.map((p) => p.phone) || [])
        const newPhones = phoneNumbers.filter((phone) => !existingSet.has(phone))

        if (newPhones.length === 0) {
          toast({
            title: "تنبيه",
            description: "جميع الأرقام موجودة مسبقاً",
            variant: "destructive",
          })
          setIsProcessing(false)
          return
        }

        // Insert into phone_numbers table
        const phoneRecords = newPhones.map((phone) => ({
          phone,
          source: file ? file.name : "manual",
          status: "pending",
          assigned_to: selectedEmployee,
          added_by: user?.id,
        }))

        const { error: insertError } = await supabase.from("phone_numbers").insert(phoneRecords)

        if (insertError) throw insertError

        // Create customers
        const customerRecords = newPhones.map((phone) => ({
          phone,
          name: phone,
          status: "new",
          source: file ? file.name : "manual",
          assigned_to: selectedEmployee,
        }))

        const { error: customerError } = await supabase.from("customers").insert(customerRecords)

        if (customerError) throw customerError

        // Send notification to employee
        const { data: employee } = await supabase.from("employees").select("name").eq("id", selectedEmployee).single()

        await supabase.from("notifications").insert({
          recipient_id: selectedEmployee,
          sender_id: user?.id,
          title: "أرقام جديدة",
          message: `تم توزيع ${newPhones.length} رقم جديد عليك`,
        })

        toast({
          title: "تم التوزيع",
          description: `تم توزيع ${newPhones.length} رقم على ${employee?.name}`,
        })
      } else {
        // Auto distribution
        if (employees.length === 0) {
          toast({
            title: "خطأ",
            description: "لا يوجد موظفين نشطين",
            variant: "destructive",
          })
          setIsProcessing(false)
          return
        }

        // Check for duplicates
        const { data: existingPhones } = await supabase.from("customers").select("phone").in("phone", phoneNumbers)

        const existingSet = new Set(existingPhones?.map((p) => p.phone) || [])
        const newPhones = phoneNumbers.filter((phone) => !existingSet.has(phone))

        if (newPhones.length === 0) {
          toast({
            title: "تنبيه",
            description: "جميع الأرقام موجودة مسبقاً",
            variant: "destructive",
          })
          setIsProcessing(false)
          return
        }

        // Distribute evenly
        const phonesPerEmployee = Math.ceil(newPhones.length / employees.length)
        let phoneIndex = 0

        for (const employee of employees) {
          const employeePhones = newPhones.slice(phoneIndex, phoneIndex + phonesPerEmployee)
          phoneIndex += phonesPerEmployee

          if (employeePhones.length === 0) continue

          // Insert into phone_numbers
          const phoneRecords = employeePhones.map((phone) => ({
            phone,
            source: file ? file.name : "manual",
            status: "pending",
            assigned_to: employee.id,
            added_by: user?.id,
          }))

          await supabase.from("phone_numbers").insert(phoneRecords)

          // Create customers
          const customerRecords = employeePhones.map((phone) => ({
            phone,
            name: phone,
            status: "new",
            source: file ? file.name : "manual",
            assigned_to: employee.id,
          }))

          await supabase.from("customers").insert(customerRecords)

          // Send notification
          await supabase.from("notifications").insert({
            recipient_id: employee.id,
            sender_id: user?.id,
            title: "أرقام جديدة",
            message: `تم توزيع ${employeePhones.length} رقم جديد عليك`,
          })
        }

        toast({
          title: "تم التوزيع",
          description: `تم توزيع ${newPhones.length} رقم على ${employees.length} موظف`,
        })
      }

      // Reset
      setPhoneNumbers([])
      setFile(null)
      setManualInput("")
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">توزيع الأرقام</h1>
        <p className="text-muted-foreground">رفع وتوزيع أرقام العملاء على الموظفين</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" />
              رفع ملف Excel/CSV
            </CardTitle>
            <CardDescription>قم برفع ملف يحتوي على أرقام الهواتف</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="file">اختر ملف</Label>
              <Input id="file" type="file" accept=".xlsx,.xls,.csv" onChange={handleFileUpload} />
            </div>
            {file && (
              <div className="rounded-lg bg-accent p-3">
                <p className="text-sm font-medium">الملف المحدد: {file.name}</p>
                <p className="text-xs text-muted-foreground">عدد الأرقام: {phoneNumbers.length}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              إدخال يدوي
            </CardTitle>
            <CardDescription>أدخل الأرقام يدوياً (رقم في كل سطر)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="manual">الأرقام</Label>
              <textarea
                id="manual"
                className="min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                placeholder="0501234567&#10;0509876543&#10;..."
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
              />
            </div>
            <Button onClick={handleManualInput} className="w-full">
              إضافة الأرقام
            </Button>
          </CardContent>
        </Card>
      </div>

      {phoneNumbers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              إعدادات التوزيع
            </CardTitle>
            <CardDescription>اختر طريقة توزيع الأرقام</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label>طريقة التوزيع</Label>
              <Select value={distributionMethod} onValueChange={(value: any) => setDistributionMethod(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">توزيع يدوي</SelectItem>
                  <SelectItem value="auto">توزيع تلقائي</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {distributionMethod === "manual" && (
              <div className="grid gap-2">
                <Label>اختر الموظف</Label>
                <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر موظف" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((emp) => (
                      <SelectItem key={emp.id} value={emp.id}>
                        {emp.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="rounded-lg bg-accent p-4">
              <p className="text-sm font-medium">عدد الأرقام المراد توزيعها: {phoneNumbers.length}</p>
              {distributionMethod === "auto" && employees.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  سيتم توزيع حوالي {Math.ceil(phoneNumbers.length / employees.length)} رقم لكل موظف
                </p>
              )}
            </div>

            <Button onClick={handleDistribute} disabled={isProcessing} className="w-full" size="lg">
              {isProcessing ? "جاري التوزيع..." : "توزيع الأرقام"}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
