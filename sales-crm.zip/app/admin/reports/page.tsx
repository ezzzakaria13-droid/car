"use client"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { Download, TrendingUp, Users, CheckCircle, Clock } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"]

export default function ReportsPage() {
  const [loading, setLoading] = useState(true)
  const [period, setPeriod] = useState("month")
  const [stats, setStats] = useState<any>(null)
  const [employeePerformance, setEmployeePerformance] = useState<any[]>([])
  const [statusDistribution, setStatusDistribution] = useState<any[]>([])
  const [dailyActivity, setDailyActivity] = useState<any[]>([])
  const { toast } = useToast()
  const supabase = createBrowserClient()

  useEffect(() => {
    loadReports()
  }, [period])

  const loadReports = async () => {
    try {
      setLoading(true)

      // Calculate date range
      const now = new Date()
      const startDate = new Date()

      if (period === "week") {
        startDate.setDate(now.getDate() - 7)
      } else if (period === "month") {
        startDate.setMonth(now.getMonth() - 1)
      } else if (period === "year") {
        startDate.setFullYear(now.getFullYear() - 1)
      }

      // Get overall stats
      const [customersRes, employeesRes, notesRes, quotesRes] = await Promise.all([
        supabase.from("customers").select("*", { count: "exact" }),
        supabase.from("employees").select("*", { count: "exact" }).eq("status", "active"),
        supabase.from("notes").select("*", { count: "exact" }).gte("created_at", startDate.toISOString()),
        supabase.from("quotations").select("*", { count: "exact" }).gte("created_at", startDate.toISOString()),
      ])

      setStats({
        totalCustomers: customersRes.count || 0,
        activeEmployees: employeesRes.count || 0,
        totalNotes: notesRes.count || 0,
        totalQuotes: quotesRes.count || 0,
      })

      // Get employee performance
      const { data: employees } = await supabase.from("employees").select("id, name").eq("status", "active")

      if (employees) {
        const performance = await Promise.all(
          employees.map(async (emp) => {
            const [customersRes, notesRes, quotesRes] = await Promise.all([
              supabase.from("customers").select("*", { count: "exact" }).eq("assigned_to", emp.id),
              supabase
                .from("notes")
                .select("*", { count: "exact" })
                .eq("employee_id", emp.id)
                .gte("created_at", startDate.toISOString()),
              supabase
                .from("quotations")
                .select("*", { count: "exact" })
                .eq("employee_id", emp.id)
                .gte("created_at", startDate.toISOString()),
            ])

            return {
              name: emp.name,
              customers: customersRes.count || 0,
              notes: notesRes.count || 0,
              quotes: quotesRes.count || 0,
            }
          }),
        )
        setEmployeePerformance(performance)
      }

      // Get status distribution
      const { data: customers } = await supabase.from("customers").select("status")

      if (customers) {
        const distribution = customers.reduce((acc: any, customer) => {
          const status = customer.status || "جديد"
          acc[status] = (acc[status] || 0) + 1
          return acc
        }, {})

        setStatusDistribution(
          Object.entries(distribution).map(([name, value]) => ({
            name,
            value,
          })),
        )
      }

      // Get daily activity for the last 7 days
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() - (6 - i))
        return date
      })

      const activity = await Promise.all(
        last7Days.map(async (date) => {
          const startOfDay = new Date(date.setHours(0, 0, 0, 0)).toISOString()
          const endOfDay = new Date(date.setHours(23, 59, 59, 999)).toISOString()

          const [notesRes, customersRes] = await Promise.all([
            supabase
              .from("notes")
              .select("*", { count: "exact" })
              .gte("created_at", startOfDay)
              .lte("created_at", endOfDay),
            supabase
              .from("customers")
              .select("*", { count: "exact" })
              .gte("created_at", startOfDay)
              .lte("created_at", endOfDay),
          ])

          return {
            date: date.toLocaleDateString("ar-EG", { month: "short", day: "numeric" }),
            notes: notesRes.count || 0,
            customers: customersRes.count || 0,
          }
        }),
      )

      setDailyActivity(activity)
    } catch (error) {
      console.error("Error loading reports:", error)
      toast({
        title: "خطأ",
        description: "فشل تحميل التقارير",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const exportReport = () => {
    const reportData = {
      period,
      generatedAt: new Date().toISOString(),
      stats,
      employeePerformance,
      statusDistribution,
      dailyActivity,
    }

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `report-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    URL.revokeObjectURL(url)

    toast({
      title: "تم التصدير",
      description: "تم تصدير التقرير بنجاح",
    })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل التقارير...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">التقارير والتحليلات</h1>
          <p className="text-muted-foreground mt-1">تحليل شامل لأداء النظام والموظفين</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">آخر أسبوع</SelectItem>
              <SelectItem value="month">آخر شهر</SelectItem>
              <SelectItem value="year">آخر سنة</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={exportReport}>
            <Download className="ml-2 h-4 w-4" />
            تصدير التقرير
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">إجمالي العملاء</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalCustomers || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">جميع العملاء في النظام</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">الموظفون النشطون</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.activeEmployees || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">موظف نشط حالياً</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">الملاحظات</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalNotes || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">في الفترة المحددة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">عروض الأسعار</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalQuotes || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">في الفترة المحددة</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">أداء الموظفين</TabsTrigger>
          <TabsTrigger value="status">توزيع الحالات</TabsTrigger>
          <TabsTrigger value="activity">النشاط اليومي</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>أداء الموظفين</CardTitle>
              <CardDescription>مقارنة أداء الموظفين في الفترة المحددة</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={employeePerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="customers" fill="#3b82f6" name="العملاء" />
                  <Bar dataKey="notes" fill="#10b981" name="الملاحظات" />
                  <Bar dataKey="quotes" fill="#f59e0b" name="عروض الأسعار" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="status" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>توزيع حالات العملاء</CardTitle>
              <CardDescription>نسبة توزيع العملاء حسب الحالة</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>النشاط اليومي</CardTitle>
              <CardDescription>نشاط النظام خلال آخر 7 أيام</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={dailyActivity}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="customers" stroke="#3b82f6" name="عملاء جدد" strokeWidth={2} />
                  <Line type="monotone" dataKey="notes" stroke="#10b981" name="ملاحظات" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
