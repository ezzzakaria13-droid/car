"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Settings, Save, Upload } from "lucide-react"

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    company_name: "",
    company_logo: "",
    company_phone: "",
    company_email: "",
    company_address: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    const { data } = await supabase.from("settings").select("*")

    if (data) {
      const settingsObj: any = {}
      data.forEach((setting) => {
        settingsObj[setting.key] = setting.value
      })
      setSettings({
        company_name: settingsObj.company_name || "",
        company_logo: settingsObj.company_logo || "",
        company_phone: settingsObj.company_phone || "",
        company_email: settingsObj.company_email || "",
        company_address: settingsObj.company_address || "",
      })
    }
  }

  const handleSave = async () => {
    setIsLoading(true)

    try {
      // Delete existing settings
      await supabase.from("settings").delete().neq("id", "00000000-0000-0000-0000-000000000000")

      // Insert new settings
      const settingsArray = Object.entries(settings).map(([key, value]) => ({
        key,
        value,
      }))

      const { error } = await supabase.from("settings").insert(settingsArray)

      if (error) throw error

      toast({
        title: "تم الحفظ",
        description: "تم حفظ الإعدادات بنجاح",
      })
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">الإعدادات</h1>
        <p className="text-muted-foreground">إدارة إعدادات النظام</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            معلومات الشركة
          </CardTitle>
          <CardDescription>تحديث معلومات الشركة والعلامة التجارية</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="company_name">اسم الشركة</Label>
            <Input
              id="company_name"
              value={settings.company_name}
              onChange={(e) => setSettings({ ...settings, company_name: e.target.value })}
              placeholder="اسم شركتك"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="company_logo">شعار الشركة (URL)</Label>
            <div className="flex gap-2">
              <Input
                id="company_logo"
                value={settings.company_logo}
                onChange={(e) => setSettings({ ...settings, company_logo: e.target.value })}
                placeholder="https://example.com/logo.png"
              />
              <Button variant="outline" size="icon">
                <Upload className="h-4 w-4" />
              </Button>
            </div>
            {settings.company_logo && (
              <div className="mt-2">
                <img
                  src={settings.company_logo || "/placeholder.svg"}
                  alt="Logo"
                  className="h-16 w-auto rounded border"
                />
              </div>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="company_phone">رقم الهاتف</Label>
            <Input
              id="company_phone"
              value={settings.company_phone}
              onChange={(e) => setSettings({ ...settings, company_phone: e.target.value })}
              placeholder="+966 50 123 4567"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="company_email">البريد الإلكتروني</Label>
            <Input
              id="company_email"
              type="email"
              value={settings.company_email}
              onChange={(e) => setSettings({ ...settings, company_email: e.target.value })}
              placeholder="info@company.com"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="company_address">العنوان</Label>
            <Input
              id="company_address"
              value={settings.company_address}
              onChange={(e) => setSettings({ ...settings, company_address: e.target.value })}
              placeholder="الرياض، المملكة العربية السعودية"
            />
          </div>

          <Button onClick={handleSave} disabled={isLoading} className="w-full" size="lg">
            <Save className="ml-2 h-4 w-4" />
            {isLoading ? "جاري الحفظ..." : "حفظ الإعدادات"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>معلومات المزامنة</CardTitle>
          <CardDescription>النظام يدعم المزامنة الفورية عبر جميع الأجهزة</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="rounded-lg bg-blue-50 p-4 text-sm text-blue-900">
            <p className="font-semibold mb-2">المزامنة التلقائية</p>
            <p>
              جميع التحديثات تتم بشكل فوري عبر جميع الأجهزة المتصلة بنفس الحساب. لا حاجة لإعادة تحميل الصفحة أو الاتصال
              بشبكة معينة.
            </p>
          </div>

          <div className="rounded-lg bg-green-50 p-4 text-sm text-green-900">
            <p className="font-semibold mb-2">التحديثات الفورية</p>
            <ul className="list-disc list-inside space-y-1">
              <li>إضافة أو تعديل العملاء</li>
              <li>توزيع الأرقام الجديدة</li>
              <li>الملاحظات والتذكيرات</li>
              <li>الإشعارات الفورية</li>
              <li>حالة المستخدمين المتصلين</li>
            </ul>
          </div>

          <div className="rounded-lg bg-purple-50 p-4 text-sm text-purple-900">
            <p className="font-semibold mb-2">متوافق مع جميع الأجهزة</p>
            <p>يعمل النظام على الكمبيوتر، الجوال، والتابلت بنفس الكفاءة مع واجهة متجاوبة تماماً.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
