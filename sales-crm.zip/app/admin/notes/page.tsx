"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, StickyNote, Bell, User } from "lucide-react"

interface Note {
  id: string
  content: string
  type: string
  created_at: string
  customer_id: string
  employee_id: string
  customers?: {
    name: string
    phone: string
  }
  employees?: {
    name: string
  }
}

export default function AdminNotesPage() {
  const [notes, setNotes] = useState<Note[]>([])
  const [filteredNotes, setFilteredNotes] = useState<Note[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const supabase = createClient()

  useEffect(() => {
    loadNotes()

    // Subscribe to real-time updates
    const channel = supabase
      .channel("notes")
      .on("postgres_changes", { event: "*", schema: "public", table: "notes" }, () => {
        loadNotes()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    let filtered = notes

    if (searchTerm) {
      filtered = filtered.filter(
        (note) =>
          note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
          note.customers?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          note.employees?.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter((note) => note.type === typeFilter)
    }

    setFilteredNotes(filtered)
  }, [searchTerm, typeFilter, notes])

  const loadNotes = async () => {
    const { data } = await supabase
      .from("notes")
      .select("*, customers(name, phone), employees(name)")
      .order("created_at", { ascending: false })

    if (data) {
      setNotes(data)
      setFilteredNotes(data)
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">ملاحظات الموظفين</h1>
        <p className="text-muted-foreground">عرض جميع الملاحظات والتذكيرات</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>قائمة الملاحظات</CardTitle>
            <div className="flex gap-2">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="البحث..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="note">ملاحظات</SelectItem>
                  <SelectItem value="reminder">تذكيرات</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredNotes.map((note) => (
              <Card
                key={note.id}
                className="border-r-4"
                style={{ borderRightColor: note.type === "reminder" ? "#f97316" : "#3b82f6" }}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {note.type === "reminder" ? (
                          <Bell className="h-4 w-4 text-orange-600" />
                        ) : (
                          <StickyNote className="h-4 w-4 text-blue-600" />
                        )}
                        <span className="font-semibold">{note.customers?.name}</span>
                        <span className="text-sm text-muted-foreground">({note.customers?.phone})</span>
                      </div>
                      <p className="text-sm mb-2">{note.content}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {note.employees?.name}
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(note.created_at).toLocaleString("ar-SA")}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
