import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Phone, CheckCircle, Clock } from "lucide-react"

export default async function AdminDashboard() {
  const supabase = await createClient()

  // Get statistics
  const { count: employeesCount } = await supabase.from("employees").select("*", { count: "exact", head: true })

  const { count: customersCount } = await supabase.from("customers").select("*", { count: "exact", head: true })

  const { count: activeLeadsCount } = await supabase
    .from("customers")
    .select("*", { count: "exact", head: true })
    .eq("status", "active")

  const { count: pendingPhones } = await supabase
    .from("phone_numbers")
    .select("*", { count: "exact", head: true })
    .eq("status", "pending")

  const stats = [
    {
      title: "عدد الموظفين",
      value: employeesCount || 0,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "إجمالي العملاء",
      value: customersCount || 0,
      icon: Phone,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "العملاء النشطين",
      value: activeLeadsCount || 0,
      icon: CheckCircle,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
    {
      title: "أرقام قيد الانتظار",
      value: pendingPhones || 0,
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
  ]

  // Get recent employees
  const { data: recentEmployees } = await supabase
    .from("employees")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5)

  // Get recent customers
  const { data: recentCustomers } = await supabase
    .from("customers")
    .select("*, employees(name)")
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">لوحة التحكم</h1>
        <p className="text-muted-foreground">نظرة عامة على النظام</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <div className={`rounded-full p-2 ${stat.bgColor}`}>
                  <Icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>أحدث الموظفين</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentEmployees?.map((employee) => (
                <div key={employee.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                  <div>
                    <p className="font-medium">{employee.name}</p>
                    <p className="text-sm text-muted-foreground">{employee.position}</p>
                  </div>
                  <span
                    className={`rounded-full px-3 py-1 text-xs ${
                      employee.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                    }`}
                  >
                    {employee.status === "active" ? "نشط" : "غير نشط"}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>أحدث العملاء</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentCustomers?.map((customer) => (
                <div key={customer.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                  <div>
                    <p className="font-medium">{customer.name}</p>
                    <p className="text-sm text-muted-foreground">{customer.phone}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-muted-foreground">المندوب</p>
                    <p className="text-sm font-medium">{customer.employees?.name || "غير محدد"}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
