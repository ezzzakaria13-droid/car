"use server"

import { createClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"

export async function loginAction(email: string, password: string) {
  console.log("[v0] Login attempt for:", email)

  const supabase = await createClient()

  try {
    const { data: employee, error } = await supabase
      .from("employees")
      .select("*")
      .eq("email", email)
      .eq("password", password)
      .eq("status", "active")
      .single()

    console.log("[v0] Employee query result:", { found: !!employee, error })

    if (error || !employee) {
      console.log("[v0] Login failed: Invalid credentials")
      return { success: false, error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" }
    }

    const cookieStore = await cookies()
    cookieStore.set("user_id", employee.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    })
    cookieStore.set("user_role", employee.role, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    })

    console.log("[v0] Login successful for:", employee.name, "Role:", employee.role)

    return {
      success: true,
      role: employee.role,
      user: {
        id: employee.id,
        name: employee.name,
        email: employee.email,
        role: employee.role,
      },
    }
  } catch (error) {
    console.error("[v0] Login error:", error)
    return { success: false, error: "حدث خطأ في تسجيل الدخول" }
  }
}

export async function logoutAction() {
  const cookieStore = await cookies()
  cookieStore.delete("user_id")
  cookieStore.delete("user_role")
  return { success: true }
}
