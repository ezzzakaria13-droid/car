import type React from "react"
import { EmployeeSidebar } from "@/components/employee/sidebar"
import { EmployeeHeader } from "@/components/employee/header"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  return (
    <div className="flex h-screen" dir="rtl">
      <EmployeeSidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <EmployeeHeader userName={user.name} />
        <main className="flex-1 overflow-y-auto bg-background p-6">{children}</main>
      </div>
    </div>
  )
}
