"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Trash2, Calendar, StickyNote, Bell } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Note {
  id: string
  content: string
  type: string
  created_at: string
  customer_id: string
  customers?: {
    name: string
    phone: string
  }
}

interface Customer {
  id: string
  name: string
  phone: string
}

export default function NotesPage() {
  const [notes, setNotes] = useState<Note[]>([])
  const [filteredNotes, setFilteredNotes] = useState<Note[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    customer_id: "",
    content: "",
    type: "note",
  })
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    loadNotes()
    loadCustomers()

    // Subscribe to real-time updates
    const channel = supabase
      .channel("notes")
      .on("postgres_changes", { event: "*", schema: "public", table: "notes" }, () => {
        loadNotes()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    let filtered = notes

    if (searchTerm) {
      filtered = filtered.filter(
        (note) =>
          note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
          note.customers?.name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter((note) => note.type === typeFilter)
    }

    setFilteredNotes(filtered)
  }, [searchTerm, typeFilter, notes])

  const loadNotes = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase
      .from("notes")
      .select("*, customers(name, phone)")
      .eq("employee_id", user.id)
      .order("created_at", { ascending: false })

    if (data) {
      setNotes(data)
      setFilteredNotes(data)
    }
  }

  const loadCustomers = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase.from("customers").select("id, name, phone").eq("assigned_to", user.id)

    if (data) {
      setCustomers(data)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const { error } = await supabase.from("notes").insert({
        ...formData,
        employee_id: user.id,
      })

      if (error) throw error

      // If it's a reminder, notify admin
      if (formData.type === "reminder") {
        const { data: admins } = await supabase.from("employees").select("id").eq("role", "admin")

        if (admins) {
          for (const admin of admins) {
            await supabase.from("notifications").insert({
              recipient_id: admin.id,
              sender_id: user.id,
              title: "تذكير جديد",
              message: `تم إضافة تذكير جديد من قبل موظف`,
            })
          }
        }
      }

      toast({
        title: "تم الإضافة",
        description: formData.type === "reminder" ? "تم إضافة التذكير بنجاح" : "تم إضافة الملاحظة بنجاح",
      })

      setIsDialogOpen(false)
      resetForm()
      loadNotes()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذه الملاحظة؟")) return

    try {
      const { error } = await supabase.from("notes").delete().eq("id", id)

      if (error) throw error

      toast({
        title: "تم الحذف",
        description: "تم حذف الملاحظة بنجاح",
      })

      loadNotes()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const resetForm = () => {
    setFormData({
      customer_id: "",
      content: "",
      type: "note",
    })
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">الملاحظات والتذكيرات</h1>
          <p className="text-muted-foreground">إدارة ملاحظاتك وتذكيراتك</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="ml-2 h-4 w-4" />
              إضافة ملاحظة/تذكير
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>إضافة ملاحظة أو تذكير</DialogTitle>
              <DialogDescription>أضف ملاحظة أو تذكير لعميل</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="customer">العميل</Label>
                <Select
                  value={formData.customer_id}
                  onValueChange={(value) => setFormData({ ...formData, customer_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر عميل" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.name} - {customer.phone}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="type">النوع</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="note">ملاحظة</SelectItem>
                    <SelectItem value="reminder">تذكير</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="content">المحتوى</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={5}
                  required
                  placeholder="اكتب الملاحظة أو التذكير هنا..."
                />
              </div>
              {formData.type === "reminder" && (
                <div className="rounded-lg bg-orange-50 p-3 text-sm text-orange-800">
                  <Bell className="mb-1 inline h-4 w-4" /> سيتم إرسال إشعار للمدير عند إضافة التذكير
                </div>
              )}
              <Button type="submit" className="w-full">
                إضافة
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>قائمة الملاحظات والتذكيرات</CardTitle>
            <div className="flex gap-2">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="البحث..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="note">ملاحظات</SelectItem>
                  <SelectItem value="reminder">تذكيرات</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredNotes.map((note) => (
              <Card
                key={note.id}
                className="border-r-4"
                style={{ borderRightColor: note.type === "reminder" ? "#f97316" : "#3b82f6" }}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {note.type === "reminder" ? (
                          <Bell className="h-4 w-4 text-orange-600" />
                        ) : (
                          <StickyNote className="h-4 w-4 text-blue-600" />
                        )}
                        <span className="font-semibold">{note.customers?.name}</span>
                        <span className="text-sm text-muted-foreground">({note.customers?.phone})</span>
                      </div>
                      <p className="text-sm mb-2">{note.content}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {new Date(note.created_at).toLocaleString("ar-SA")}
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(note.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
