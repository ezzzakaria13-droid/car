"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Search, Plus, Pencil, Send } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { formatPhone, getWhatsAppLink } from "@/lib/phone-utils"

interface Customer {
  id: string
  name: string
  phone: string
  email: string | null
  status: string
  notes: string | null
  source: string
  created_at: string
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([])
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    status: "new",
    notes: "",
  })
  const [messageData, setMessageData] = useState({
    message: "",
    file: null as File | null,
  })
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    loadCustomers()

    // Subscribe to real-time updates
    const channel = supabase
      .channel("customers")
      .on("postgres_changes", { event: "*", schema: "public", table: "customers" }, () => {
        loadCustomers()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    let filtered = customers

    if (searchTerm) {
      filtered = filtered.filter(
        (customer) =>
          customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.phone.includes(searchTerm) ||
          customer.email?.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter((customer) => customer.status === statusFilter)
    }

    setFilteredCustomers(filtered)
  }, [searchTerm, statusFilter, customers])

  const loadCustomers = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase
      .from("customers")
      .select("*")
      .eq("assigned_to", user.id)
      .order("created_at", { ascending: false })

    if (data) {
      setCustomers(data)
      setFilteredCustomers(data)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      if (selectedCustomer) {
        // Update existing customer
        const { error } = await supabase.from("customers").update(formData).eq("id", selectedCustomer.id)

        if (error) throw error

        toast({
          title: "تم التحديث",
          description: "تم تحديث بيانات العميل بنجاح",
        })
      } else {
        // Create new customer
        const { error } = await supabase.from("customers").insert({
          ...formData,
          assigned_to: user.id,
        })

        if (error) throw error

        toast({
          title: "تم الإضافة",
          description: "تم إضافة العميل بنجاح",
        })
      }

      setIsDialogOpen(false)
      resetForm()
      loadCustomers()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (customer: Customer) => {
    setSelectedCustomer(customer)
    setFormData({
      name: customer.name,
      phone: customer.phone,
      email: customer.email || "",
      status: customer.status,
      notes: customer.notes || "",
    })
    setIsDialogOpen(true)
  }

  const openMessageDialog = (customer: Customer) => {
    setSelectedCustomer(customer)
    setIsMessageDialogOpen(true)
  }

  const handleSendMessage = () => {
    if (!selectedCustomer) return

    const message = messageData.message
    const whatsappUrl = getWhatsAppLink(selectedCustomer.phone, message)

    // Open WhatsApp
    window.open(whatsappUrl, "_blank")

    toast({
      title: "تم فتح الواتساب",
      description: "يمكنك الآن إرسال الرسالة",
    })

    setIsMessageDialogOpen(false)
    setMessageData({ message: "", file: null })
  }

  const resetForm = () => {
    setSelectedCustomer(null)
    setFormData({
      name: "",
      phone: "",
      email: "",
      status: "new",
      notes: "",
    })
  }

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; className: string }> = {
      new: { label: "جديد", className: "bg-blue-100 text-blue-700" },
      active: { label: "نشط", className: "bg-green-100 text-green-700" },
      contacted: { label: "تم التواصل", className: "bg-purple-100 text-purple-700" },
      interested: { label: "مهتم", className: "bg-orange-100 text-orange-700" },
      closed: { label: "مغلق", className: "bg-gray-100 text-gray-700" },
    }

    const config = statusMap[status] || { label: status, className: "bg-gray-100 text-gray-700" }
    return <span className={`rounded-full px-3 py-1 text-xs ${config.className}`}>{config.label}</span>
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">عملائي</h1>
          <p className="text-muted-foreground">إدارة العملاء المعينين لك</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="ml-2 h-4 w-4" />
              إضافة عميل
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{selectedCustomer ? "تعديل عميل" : "إضافة عميل جديد"}</DialogTitle>
              <DialogDescription>
                {selectedCustomer ? "تعديل بيانات العميل" : "أدخل بيانات العميل الجديد"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="name">الاسم</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">رقم الهاتف</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="status">الحالة</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">جديد</SelectItem>
                    <SelectItem value="active">نشط</SelectItem>
                    <SelectItem value="contacted">تم التواصل</SelectItem>
                    <SelectItem value="interested">مهتم</SelectItem>
                    <SelectItem value="closed">مغلق</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="notes">ملاحظات</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full">
                {selectedCustomer ? "تحديث" : "إضافة"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>قائمة العملاء</CardTitle>
            <div className="flex gap-2">
              <div className="relative flex-1 md:w-64">
                <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="البحث عن عميل..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  <SelectItem value="new">جديد</SelectItem>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="contacted">تم التواصل</SelectItem>
                  <SelectItem value="interested">مهتم</SelectItem>
                  <SelectItem value="closed">مغلق</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="p-3 text-right font-semibold">الاسم</th>
                  <th className="p-3 text-right font-semibold">الهاتف</th>
                  <th className="p-3 text-right font-semibold">البريد</th>
                  <th className="p-3 text-right font-semibold">الحالة</th>
                  <th className="p-3 text-right font-semibold">التاريخ</th>
                  <th className="p-3 text-right font-semibold">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="border-b hover:bg-accent/50">
                    <td className="p-3 font-medium">{customer.name}</td>
                    <td className="p-3">
                      <a
                        href={getWhatsAppLink(customer.phone)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-blue-600 hover:underline"
                      >
                        <MessageSquare className="h-4 w-4" />
                        {formatPhone(customer.phone)}
                      </a>
                    </td>
                    <td className="p-3 text-sm text-muted-foreground">{customer.email || "-"}</td>
                    <td className="p-3">{getStatusBadge(customer.status)}</td>
                    <td className="p-3 text-sm text-muted-foreground">
                      {new Date(customer.created_at).toLocaleDateString("ar-SA")}
                    </td>
                    <td className="p-3">
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" onClick={() => openEditDialog(customer)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => openMessageDialog(customer)}>
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={isMessageDialogOpen} onOpenChange={setIsMessageDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إرسال رسالة واتساب</DialogTitle>
            <DialogDescription>إرسال رسالة إلى {selectedCustomer?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="message">الرسالة</Label>
              <Textarea
                id="message"
                value={messageData.message}
                onChange={(e) => setMessageData({ ...messageData, message: e.target.value })}
                rows={5}
                placeholder="اكتب رسالتك هنا..."
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="file">إرفاق ملف (اختياري)</Label>
              <Input
                id="file"
                type="file"
                onChange={(e) => setMessageData({ ...messageData, file: e.target.files?.[0] || null })}
              />
              <p className="text-xs text-muted-foreground">ملاحظة: سيتم فتح الواتساب ويمكنك إرفاق الملف يدوياً</p>
            </div>
            <Button onClick={handleSendMessage} className="w-full">
              <MessageSquare className="ml-2 h-4 w-4" />
              فتح الواتساب
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
