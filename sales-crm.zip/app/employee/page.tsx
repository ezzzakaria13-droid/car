import { createClient } from "@/lib/supabase/server"
import { getCurrentUser } from "@/lib/auth"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Phone, CheckCircle, Clock } from "lucide-react"

export default async function EmployeeDashboard() {
  const supabase = await createClient()
  const user = await getCurrentUser()

  if (!user) return null

  // Get statistics
  const { count: myCustomersCount } = await supabase
    .from("customers")
    .select("*", { count: "exact", head: true })
    .eq("assigned_to", user.id)

  const { count: newLeadsCount } = await supabase
    .from("customers")
    .select("*", { count: "exact", head: true })
    .eq("assigned_to", user.id)
    .eq("status", "new")

  const { count: activeLeadsCount } = await supabase
    .from("customers")
    .select("*", { count: "exact", head: true })
    .eq("assigned_to", user.id)
    .eq("status", "active")

  const { count: myNotesCount } = await supabase
    .from("notes")
    .select("*", { count: "exact", head: true })
    .eq("employee_id", user.id)

  const stats = [
    {
      title: "إجمالي عملائي",
      value: myCustomersCount || 0,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "عملاء جدد",
      value: newLeadsCount || 0,
      icon: Phone,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "عملاء نشطين",
      value: activeLeadsCount || 0,
      icon: CheckCircle,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
    {
      title: "ملاحظاتي",
      value: myNotesCount || 0,
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
  ]

  // Get recent customers
  const { data: recentCustomers } = await supabase
    .from("customers")
    .select("*")
    .eq("assigned_to", user.id)
    .order("created_at", { ascending: false })
    .limit(5)

  // Get recent notes
  const { data: recentNotes } = await supabase
    .from("notes")
    .select("*, customers(name, phone)")
    .eq("employee_id", user.id)
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">لوحة التحكم</h1>
        <p className="text-muted-foreground">نظرة عامة على عملك</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <div className={`rounded-full p-2 ${stat.bgColor}`}>
                  <Icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>أحدث العملاء</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentCustomers?.map((customer) => (
                <div key={customer.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                  <div>
                    <p className="font-medium">{customer.name}</p>
                    <p className="text-sm text-muted-foreground">{customer.phone}</p>
                  </div>
                  <span
                    className={`rounded-full px-3 py-1 text-xs ${
                      customer.status === "active"
                        ? "bg-green-100 text-green-700"
                        : customer.status === "new"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-gray-100 text-gray-700"
                    }`}
                  >
                    {customer.status === "active" ? "نشط" : customer.status === "new" ? "جديد" : customer.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>أحدث الملاحظات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentNotes?.map((note) => (
                <div key={note.id} className="border-b pb-3 last:border-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium">{note.customers?.name}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2">{note.content}</p>
                    </div>
                    <span
                      className={`rounded-full px-2 py-1 text-xs ${
                        note.type === "reminder" ? "bg-orange-100 text-orange-700" : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {note.type === "reminder" ? "تذكير" : "ملاحظة"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
