"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calculator, Download, Share2 } from "lucide-react"

export default function FinancingPage() {
  const [carPrice, setCarPrice] = useState<number>(0)
  const [downPayment, setDownPayment] = useState<number>(0)
  const [years, setYears] = useState<number>(5)
  const [interestRate, setInterestRate] = useState<number>(3.5)
  const [adminFees, setAdminFees] = useState<number>(0)
  const [insurance, setInsurance] = useState<number>(0)
  const [result, setResult] = useState<{
    loanAmount: number
    monthlyPayment: number
    totalPayment: number
    totalInterest: number
    schedule: Array<{
      month: number
      payment: number
      principal: number
      interest: number
      balance: number
    }>
  } | null>(null)

  const calculateFinancing = () => {
    const principal = carPrice - downPayment
    const monthlyRate = interestRate / 100 / 12
    const numberOfPayments = years * 12

    // Calculate monthly payment using the formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
    const monthlyPayment =
      (principal * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
      (Math.pow(1 + monthlyRate, numberOfPayments) - 1)

    const totalPayment = monthlyPayment * numberOfPayments + downPayment + adminFees + insurance
    const totalInterest = monthlyPayment * numberOfPayments - principal

    // Generate amortization schedule
    const schedule = []
    let balance = principal

    for (let month = 1; month <= numberOfPayments; month++) {
      const interestPayment = balance * monthlyRate
      const principalPayment = monthlyPayment - interestPayment
      balance -= principalPayment

      schedule.push({
        month,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: Math.max(0, balance),
      })
    }

    setResult({
      loanAmount: principal,
      monthlyPayment,
      totalPayment,
      totalInterest,
      schedule,
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ar-SA", {
      style: "currency",
      currency: "SAR",
      minimumFractionDigits: 2,
    }).format(amount)
  }

  const handleDownloadPDF = () => {
    // In a real implementation, you would generate a PDF here
    alert("سيتم تنزيل ملف PDF قريباً")
  }

  const handleShare = () => {
    const text = `
حاسبة التمويل
سعر السيارة: ${formatCurrency(carPrice)}
الدفعة المقدمة: ${formatCurrency(downPayment)}
مبلغ التمويل: ${formatCurrency(result?.loanAmount || 0)}
القسط الشهري: ${formatCurrency(result?.monthlyPayment || 0)}
المدة: ${years} سنوات
    `.trim()

    if (navigator.share) {
      navigator.share({
        title: "حاسبة التمويل",
        text: text,
      })
    } else {
      navigator.clipboard.writeText(text)
      alert("تم نسخ التفاصيل")
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">حاسبة التمويل</h1>
        <p className="text-muted-foreground">احسب أقساط التمويل للعملاء</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              بيانات التمويل
            </CardTitle>
            <CardDescription>أدخل تفاصيل التمويل لحساب الأقساط</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="carPrice">سعر السيارة (ريال)</Label>
              <Input
                id="carPrice"
                type="number"
                value={carPrice || ""}
                onChange={(e) => setCarPrice(Number(e.target.value))}
                placeholder="0"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="downPayment">الدفعة المقدمة (ريال)</Label>
              <Input
                id="downPayment"
                type="number"
                value={downPayment || ""}
                onChange={(e) => setDownPayment(Number(e.target.value))}
                placeholder="0"
              />
              {carPrice > 0 && (
                <p className="text-xs text-muted-foreground">
                  نسبة الدفعة المقدمة: {((downPayment / carPrice) * 100).toFixed(1)}%
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="years">مدة التمويل</Label>
              <Select value={years.toString()} onValueChange={(value) => setYears(Number(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">سنة واحدة</SelectItem>
                  <SelectItem value="2">سنتان</SelectItem>
                  <SelectItem value="3">3 سنوات</SelectItem>
                  <SelectItem value="4">4 سنوات</SelectItem>
                  <SelectItem value="5">5 سنوات</SelectItem>
                  <SelectItem value="6">6 سنوات</SelectItem>
                  <SelectItem value="7">7 سنوات</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="interestRate">نسبة الفائدة السنوية (%)</Label>
              <Input
                id="interestRate"
                type="number"
                step="0.1"
                value={interestRate || ""}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                placeholder="3.5"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="adminFees">الرسوم الإدارية (ريال)</Label>
              <Input
                id="adminFees"
                type="number"
                value={adminFees || ""}
                onChange={(e) => setAdminFees(Number(e.target.value))}
                placeholder="0"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="insurance">التأمين الشامل (ريال)</Label>
              <Input
                id="insurance"
                type="number"
                value={insurance || ""}
                onChange={(e) => setInsurance(Number(e.target.value))}
                placeholder="0"
              />
            </div>

            <Button onClick={calculateFinancing} className="w-full" size="lg">
              <Calculator className="ml-2 h-4 w-4" />
              احسب الأقساط
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>نتائج الحساب</CardTitle>
                <CardDescription>تفاصيل التمويل والأقساط</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <div className="flex items-center justify-between rounded-lg bg-blue-50 p-4">
                    <span className="text-sm font-medium text-blue-900">مبلغ التمويل</span>
                    <span className="text-lg font-bold text-blue-900">{formatCurrency(result.loanAmount)}</span>
                  </div>

                  <div className="flex items-center justify-between rounded-lg bg-green-50 p-4">
                    <span className="text-sm font-medium text-green-900">القسط الشهري</span>
                    <span className="text-2xl font-bold text-green-900">{formatCurrency(result.monthlyPayment)}</span>
                  </div>

                  <div className="flex items-center justify-between rounded-lg bg-purple-50 p-4">
                    <span className="text-sm font-medium text-purple-900">إجمالي المبلغ المدفوع</span>
                    <span className="text-lg font-bold text-purple-900">{formatCurrency(result.totalPayment)}</span>
                  </div>

                  <div className="flex items-center justify-between rounded-lg bg-orange-50 p-4">
                    <span className="text-sm font-medium text-orange-900">إجمالي الفوائد</span>
                    <span className="text-lg font-bold text-orange-900">{formatCurrency(result.totalInterest)}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleDownloadPDF} variant="outline" className="flex-1 bg-transparent">
                    <Download className="ml-2 h-4 w-4" />
                    تنزيل PDF
                  </Button>
                  <Button onClick={handleShare} variant="outline" className="flex-1 bg-transparent">
                    <Share2 className="ml-2 h-4 w-4" />
                    مشاركة
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>جدول الأقساط</CardTitle>
                <CardDescription>تفاصيل الأقساط الشهرية</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="max-h-96 overflow-y-auto">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-background">
                      <tr className="border-b">
                        <th className="p-2 text-right font-semibold">الشهر</th>
                        <th className="p-2 text-right font-semibold">القسط</th>
                        <th className="p-2 text-right font-semibold">الأصل</th>
                        <th className="p-2 text-right font-semibold">الفائدة</th>
                        <th className="p-2 text-right font-semibold">الرصيد</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.schedule.map((row) => (
                        <tr key={row.month} className="border-b hover:bg-accent/50">
                          <td className="p-2">{row.month}</td>
                          <td className="p-2">{formatCurrency(row.payment)}</td>
                          <td className="p-2 text-green-600">{formatCurrency(row.principal)}</td>
                          <td className="p-2 text-orange-600">{formatCurrency(row.interest)}</td>
                          <td className="p-2 font-medium">{formatCurrency(row.balance)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
