"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Trash2, Eye, FileText } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Quote {
  id: string
  customer_id: string
  total: number
  status: string
  items: Array<{
    name: string
    description: string
    quantity: number
    price: number
  }>
  created_at: string
  customers?: {
    name: string
    phone: string
  }
}

interface Customer {
  id: string
  name: string
  phone: string
}

export default function QuotesPage() {
  const [quotes, setQuotes] = useState<Quote[]>([])
  const [filteredQuotes, setFilteredQuotes] = useState<Quote[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null)
  const [formData, setFormData] = useState({
    customer_id: "",
    items: [{ name: "", description: "", quantity: 1, price: 0 }],
  })
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    loadQuotes()
    loadCustomers()

    // Subscribe to real-time updates
    const channel = supabase
      .channel("quotations")
      .on("postgres_changes", { event: "*", schema: "public", table: "quotations" }, () => {
        loadQuotes()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    let filtered = quotes

    if (searchTerm) {
      filtered = filtered.filter((quote) => quote.customers?.name.toLowerCase().includes(searchTerm.toLowerCase()))
    }

    setFilteredQuotes(filtered)
  }, [searchTerm, quotes])

  const loadQuotes = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase
      .from("quotations")
      .select("*, customers(name, phone)")
      .eq("employee_id", user.id)
      .order("created_at", { ascending: false })

    if (data) {
      setQuotes(data)
      setFilteredQuotes(data)
    }
  }

  const loadCustomers = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) return

    const { data } = await supabase.from("customers").select("id, name, phone").eq("assigned_to", user.id)

    if (data) {
      setCustomers(data)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const total = formData.items.reduce((sum, item) => sum + item.quantity * item.price, 0)

      const { error } = await supabase.from("quotations").insert({
        customer_id: formData.customer_id,
        employee_id: user.id,
        items: formData.items,
        total,
        status: "pending",
      })

      if (error) throw error

      toast({
        title: "تم الإضافة",
        description: "تم إنشاء عرض السعر بنجاح",
      })

      setIsDialogOpen(false)
      resetForm()
      loadQuotes()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف عرض السعر؟")) return

    try {
      const { error } = await supabase.from("quotations").delete().eq("id", id)

      if (error) throw error

      toast({
        title: "تم الحذف",
        description: "تم حذف عرض السعر بنجاح",
      })

      loadQuotes()
    } catch (error: any) {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { name: "", description: "", quantity: 1, price: 0 }],
    })
  }

  const removeItem = (index: number) => {
    const newItems = formData.items.filter((_, i) => i !== index)
    setFormData({ ...formData, items: newItems })
  }

  const updateItem = (index: number, field: string, value: any) => {
    const newItems = [...formData.items]
    newItems[index] = { ...newItems[index], [field]: value }
    setFormData({ ...formData, items: newItems })
  }

  const resetForm = () => {
    setFormData({
      customer_id: "",
      items: [{ name: "", description: "", quantity: 1, price: 0 }],
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ar-SA", {
      style: "currency",
      currency: "SAR",
      minimumFractionDigits: 2,
    }).format(amount)
  }

  const openViewDialog = (quote: Quote) => {
    setSelectedQuote(quote)
    setIsViewDialogOpen(true)
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">عروض الأسعار</h1>
          <p className="text-muted-foreground">إنشاء وإدارة عروض الأسعار للعملاء</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="ml-2 h-4 w-4" />
              إنشاء عرض سعر
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>إنشاء عرض سعر جديد</DialogTitle>
              <DialogDescription>أضف تفاصيل عرض السعر</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="customer">العميل</Label>
                <Select
                  value={formData.customer_id}
                  onValueChange={(value) => setFormData({ ...formData, customer_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر عميل" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.name} - {customer.phone}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>البنود</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addItem}>
                    <Plus className="ml-2 h-3 w-3" />
                    إضافة بند
                  </Button>
                </div>

                {formData.items.map((item, index) => (
                  <Card key={index}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">البند {index + 1}</span>
                        {formData.items.length > 1 && (
                          <Button type="button" variant="ghost" size="sm" onClick={() => removeItem(index)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        )}
                      </div>

                      <div className="grid gap-3 md:grid-cols-2">
                        <div className="grid gap-2">
                          <Label>الاسم</Label>
                          <Input
                            value={item.name}
                            onChange={(e) => updateItem(index, "name", e.target.value)}
                            required
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>الوصف</Label>
                          <Input
                            value={item.description}
                            onChange={(e) => updateItem(index, "description", e.target.value)}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>الكمية</Label>
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateItem(index, "quantity", Number(e.target.value))}
                            required
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label>السعر (ريال)</Label>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.price}
                            onChange={(e) => updateItem(index, "price", Number(e.target.value))}
                            required
                          />
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t">
                        <span className="text-sm text-muted-foreground">المجموع</span>
                        <span className="font-semibold">{formatCurrency(item.quantity * item.price)}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex justify-between items-center rounded-lg bg-primary/10 p-4">
                <span className="text-lg font-semibold">الإجمالي</span>
                <span className="text-2xl font-bold text-primary">
                  {formatCurrency(formData.items.reduce((sum, item) => sum + item.quantity * item.price, 0))}
                </span>
              </div>

              <Button type="submit" className="w-full">
                إنشاء عرض السعر
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle>قائمة عروض الأسعار</CardTitle>
            <div className="relative flex-1 md:w-64">
              <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="البحث عن عميل..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="p-3 text-right font-semibold">العميل</th>
                  <th className="p-3 text-right font-semibold">عدد البنود</th>
                  <th className="p-3 text-right font-semibold">الإجمالي</th>
                  <th className="p-3 text-right font-semibold">التاريخ</th>
                  <th className="p-3 text-right font-semibold">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredQuotes.map((quote) => (
                  <tr key={quote.id} className="border-b hover:bg-accent/50">
                    <td className="p-3">
                      <div>
                        <p className="font-medium">{quote.customers?.name}</p>
                        <p className="text-sm text-muted-foreground">{quote.customers?.phone}</p>
                      </div>
                    </td>
                    <td className="p-3">{quote.items.length}</td>
                    <td className="p-3 font-semibold text-primary">{formatCurrency(quote.total)}</td>
                    <td className="p-3 text-sm text-muted-foreground">
                      {new Date(quote.created_at).toLocaleDateString("ar-SA")}
                    </td>
                    <td className="p-3">
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" onClick={() => openViewDialog(quote)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(quote.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              تفاصيل عرض السعر
            </DialogTitle>
          </DialogHeader>
          {selectedQuote && (
            <div className="space-y-4">
              <div className="rounded-lg bg-accent p-4">
                <p className="text-sm text-muted-foreground">العميل</p>
                <p className="font-semibold">{selectedQuote.customers?.name}</p>
                <p className="text-sm text-muted-foreground">{selectedQuote.customers?.phone}</p>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">البنود</h3>
                {selectedQuote.items.map((item, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-medium">{item.name}</p>
                          {item.description && <p className="text-sm text-muted-foreground">{item.description}</p>}
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-muted-foreground">
                          {item.quantity} × {formatCurrency(item.price)}
                        </span>
                        <span className="font-semibold">{formatCurrency(item.quantity * item.price)}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex justify-between items-center rounded-lg bg-primary/10 p-4">
                <span className="text-lg font-semibold">الإجمالي</span>
                <span className="text-2xl font-bold text-primary">{formatCurrency(selectedQuote.total)}</span>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
