"use client"

import { useEffect, useState } from "react"
import { getRealtimeSync } from "@/lib/realtime-sync"

export function useRealtimeTable<T>(tableName: string, initialData: T[], filter?: { column: string; value: string }) {
  const [data, setData] = useState<T[]>(initialData)
  const realtimeSync = getRealtimeSync()

  useEffect(() => {
    setData(initialData)

    const unsubscribe = realtimeSync.subscribeToTable(
      tableName,
      (payload) => {
        if (payload.eventType === "INSERT") {
          setData((prev) => [payload.new as T, ...prev])
        } else if (payload.eventType === "UPDATE") {
          setData((prev) => prev.map((item: any) => (item.id === payload.new.id ? (payload.new as T) : item)))
        } else if (payload.eventType === "DELETE") {
          setData((prev) => prev.filter((item: any) => item.id !== payload.old.id))
        }
      },
      filter,
    )

    return () => {
      unsubscribe()
    }
  }, [tableName, initialData, filter])

  return data
}
