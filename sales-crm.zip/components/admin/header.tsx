"use client"

import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { RealtimeStatus } from "@/components/realtime-status"

interface Notification {
  id: string
  title: string
  message: string
  is_read: boolean
  created_at: string
}

export function AdminHeader({ userName, userId }: { userName: string; userId: string }) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const supabase = createClient()

  useEffect(() => {
    loadNotifications()

    // Subscribe to real-time notifications
    const channel = supabase
      .channel("notifications")
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications" }, () => {
        loadNotifications()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [userId])

  const loadNotifications = async () => {
    console.log("[v0] Loading notifications for user:", userId)

    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("recipient_id", userId)
      .order("created_at", { ascending: false })
      .limit(10)

    if (data) {
      console.log("[v0] Loaded notifications:", data.length)
      setNotifications(data)
      setUnreadCount(data.filter((n) => !n.is_read).length)
    }
  }

  const markAsRead = async (id: string) => {
    await supabase.from("notifications").update({ is_read: true }).eq("id", id)
    loadNotifications()
  }

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-card px-6" dir="rtl">
      <div>
        <h2 className="text-xl font-semibold">مرحباً، {userName}</h2>
        <p className="text-sm text-muted-foreground">لوحة تحكم المدير</p>
      </div>

      <div className="flex items-center gap-4">
        <RealtimeStatus />

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <Badge className="absolute -left-1 -top-1 h-5 w-5 rounded-full p-0 text-xs" variant="destructive">
                  {unreadCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="end">
            <div className="space-y-4">
              <h3 className="font-semibold">الإشعارات</h3>
              {notifications.length === 0 ? (
                <p className="text-sm text-muted-foreground">لا توجد إشعارات</p>
              ) : (
                <div className="space-y-2">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={cn(
                        "rounded-lg border p-3 cursor-pointer hover:bg-accent",
                        !notification.is_read && "bg-accent/50",
                      )}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <p className="font-medium text-sm">{notification.title}</p>
                      <p className="text-xs text-muted-foreground">{notification.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </header>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(" ")
}
