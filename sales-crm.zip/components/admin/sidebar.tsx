"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Users,
  Phone,
  MessageSquare,
  FileText,
  BarChart3,
  Settings,
  LogOut,
  FolderOpen,
} from "lucide-react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

const menuItems = [
  { icon: LayoutDashboard, label: "لوحة التحكم", href: "/admin" },
  { icon: Users, label: "إدارة الموظفين", href: "/admin/employees" },
  { icon: Phone, label: "توزيع الأرقام", href: "/admin/distribution" },
  { icon: MessageSquare, label: "طابور الواتساب", href: "/admin/whatsapp-queue" },
  { icon: FileText, label: "الملاحظات", href: "/admin/notes" },
  { icon: FolderOpen, label: "إدارة الملفات", href: "/admin/files" },
  { icon: BarChart3, label: "التقارير", href: "/admin/reports" },
  { icon: Settings, label: "الإعدادات", href: "/admin/settings" },
]

export function AdminSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  return (
    <div className="flex h-screen w-64 flex-col border-l border-border bg-card" dir="rtl">
      <div className="flex h-16 items-center justify-center border-b border-border bg-primary px-6">
        <h1 className="text-xl font-bold text-primary-foreground">نظام إدارة المبيعات</h1>
      </div>

      <nav className="flex-1 space-y-1 p-4">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActive ? "secondary" : "ghost"}
                className={cn("w-full justify-start gap-3", isActive && "bg-secondary")}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Button>
            </Link>
          )
        })}
      </nav>

      <div className="border-t border-border p-4">
        <Button variant="destructive" className="w-full justify-start gap-3" onClick={handleLogout}>
          <LogOut className="h-5 w-5" />
          <span>تسجيل الخروج</span>
        </Button>
      </div>
    </div>
  )
}
