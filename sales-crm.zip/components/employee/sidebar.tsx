"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { LayoutDashboard, Users, StickyNote, FileText, Calculator, LogOut, FolderOpen } from "lucide-react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

const menuItems = [
  { icon: LayoutDashboard, label: "لوحة التحكم", href: "/employee" },
  { icon: Users, label: "عملائي", href: "/employee/customers" },
  { icon: StickyNote, label: "الملاحظات والتذكيرات", href: "/employee/notes" },
  { icon: Calculator, label: "حاسبة التمويل", href: "/employee/financing" },
  { icon: FileText, label: "عروض الأسعار", href: "/employee/quotes" },
  { icon: FolderOpen, label: "الملفات المشتركة", href: "/employee/files" },
]

export function EmployeeSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClient()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  return (
    <div className="flex h-screen w-64 flex-col border-l border-border bg-card" dir="rtl">
      <div className="flex h-16 items-center justify-center border-b border-border bg-primary px-6">
        <h1 className="text-xl font-bold text-primary-foreground">لوحة الموظف</h1>
      </div>

      <nav className="flex-1 space-y-1 p-4">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActive ? "secondary" : "ghost"}
                className={cn("w-full justify-start gap-3", isActive && "bg-secondary")}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Button>
            </Link>
          )
        })}
      </nav>

      <div className="border-t border-border p-4">
        <Button variant="destructive" className="w-full justify-start gap-3" onClick={handleLogout}>
          <LogOut className="h-5 w-5" />
          <span>تسجيل الخروج</span>
        </Button>
      </div>
    </div>
  )
}
