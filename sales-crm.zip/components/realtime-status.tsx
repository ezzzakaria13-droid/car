"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Wifi, WifiOff, Users } from "lucide-react"
import { getRealtimeSync } from "@/lib/realtime-sync"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"

interface OnlineUser {
  user_id: string
  name: string
  role: string
  online_at: string
}

export function RealtimeStatus() {
  const [isConnected, setIsConnected] = useState(true)
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([])
  const realtimeSync = getRealtimeSync()

  useEffect(() => {
    // Monitor connection status
    const checkConnection = setInterval(() => {
      setIsConnected(navigator.onLine)
    }, 3000)

    // Subscribe to presence
    const unsubscribe = realtimeSync.subscribeToPresence(
      "crm_system",
      (user: OnlineUser) => {
        setOnlineUsers((prev) => {
          const exists = prev.find((u) => u.user_id === user.user_id)
          if (exists) return prev
          return [...prev, user]
        })
      },
      (user: OnlineUser) => {
        setOnlineUsers((prev) => prev.filter((u) => u.user_id !== user.user_id))
      },
    )

    return () => {
      clearInterval(checkConnection)
      unsubscribe()
    }
  }, [])

  return (
    <div className="flex items-center gap-2">
      <Badge variant={isConnected ? "default" : "destructive"} className="gap-1">
        {isConnected ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
        {isConnected ? "متصل" : "غير متصل"}
      </Badge>

      <Popover>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2">
            <Users className="h-4 w-4" />
            <span className="text-sm">{onlineUsers.length}</span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64" align="end">
          <div className="space-y-3">
            <h3 className="font-semibold text-sm">المستخدمون المتصلون</h3>
            {onlineUsers.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد مستخدمون متصلون</p>
            ) : (
              <div className="space-y-2">
                {onlineUsers.map((user) => (
                  <div key={user.user_id} className="flex items-center justify-between text-sm">
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.role === "admin" ? "مدير" : "موظف"}</p>
                    </div>
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
